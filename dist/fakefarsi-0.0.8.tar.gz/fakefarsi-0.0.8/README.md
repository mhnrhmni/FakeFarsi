# FakeFarsi
 
This package, developed with Python language, is used to generate fake information including name, surname, age, phone number and email of a fake Iranian person. In Python, there was such a package called Faker, which provided fake information of a foreigner, but now we have fixed this problem for Iranians and we will improve it day by day.

Developer: Mahan Rahmani
